//
//  main.cpp
//  problem_01
//
//  Created by Artur Barčij on 03/10/2020.
//  Copyright © 2020 Artur Barčij. All rights reserved.
//

#include <iostream>
using namespace std;


//multiple_3_n_5() {
//
//
//    int sum = 0;
//    for (int i = 1; i < 10; i++) {
//
//
//
//        if (i % 3 == 0) {
//
//            sum += i;
//
//        } else if (i % 5 == 0) {
//             sum += i;
//            }
//             cout << 0 << endl;
//        }
//    cout << sum << endl;
//   }
    




